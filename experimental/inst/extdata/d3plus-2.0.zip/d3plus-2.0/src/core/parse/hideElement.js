module.exports = function(elem) {

  elem
    .style("position","absolute","important")
    .style("clip","rect(1px 1px 1px 1px)","important")
    .style("clip","rect(1px, 1px, 1px, 1px)","important")
    .style("width","1px","important")
    .style("height","1px","important")
    .style("margin","-1px","important")
    .style("padding","0","important")
    .style("border","0","important")
    .style("overflow","hidden","important");

}
