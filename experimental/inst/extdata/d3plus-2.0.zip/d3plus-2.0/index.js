'use strict';

require('./src/libs.coffee')

module.exports = require('./src/init.coffee')
